<?php
/**
 * Closing markups of main section.
 *
 * @package JupiterX\Framework\Templates\Structure
 *
 * @since   1.0.0
 */

			jupiterx_close_markup_e( 'jupiterx_primary', 'div' );

		jupiterx_close_markup_e( 'jupiterx_main_grid', 'div' );

	jupiterx_close_markup_e( 'jupiterx_fixed_wrap[_main_content]', 'div' );

jupiterx_close_markup_e( 'jupiterx_main_content', 'div' );
